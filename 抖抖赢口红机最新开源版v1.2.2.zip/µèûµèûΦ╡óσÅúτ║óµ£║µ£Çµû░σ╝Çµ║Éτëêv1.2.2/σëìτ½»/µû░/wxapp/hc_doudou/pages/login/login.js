var t, e, a = getApp();

Page({
    data: {
        videoPlay: !0,
        examine: !0,
        noexamine: !0
    },
    pass: function() {
        this.setData({
            videoPlay: !0
        }), wx.reLaunch({
            url: "../index/index"
        });
    },
    end: function() {
        this.setData({
            videoPlay: !0
        }), wx.reLaunch({
            url: "../index/index"
        });
    },
    onLoad: function(t) {
        console.log("options", t), t.pid && wx.setStorageSync("pid", t.pid), t.scene && wx.setStorageSync("pid", t.scene);
        var e = a.globalData.screenHeight, o = a.globalData.screenWidth;
        this.setData({
            screenWidth: o,
            screenHeight: e
        });
    },
    sys: function() {
        var o = this, i = this;
        a.util.request({
            url: "entry/wxapp/sys",
            method: "POST",
            success: function(n) {
                var s = n.data.data;
                wx.setNavigationBarColor({
                    frontColor: s.basic.fontcolor,
                    backgroundColor: s.basic.color
                }), wx.setNavigationBarTitle({
                    title: s.basic.title
                }), a.globalData.sys = s, 0 == s.stake ? (t = !1, e = !0) : (t = !0, e = !1), 0 == s.basic.video_status && s.basic.video ? (o.videoContext = wx.createVideoContext("myVideo"), 
                o.videoContext.play(), i.setData({
                    videoPlay: !1
                })) : wx.reLaunch({
                    url: "../index/index"
                }), i.setData({
                    sys: s,
                    examine: t,
                    noexamine: e
                });
            }
        });
    },
    Checkgoods: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/Checkgoods",
            method: "POST",
            success: function(e) {
                t.setData({
                    goodss: e.data.data
                });
            }
        });
    },
    details: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../detail/detail?id=" + e
        });
    },
    onShow: function() {
        Promise.all([ this.sys(), this.Checkgoods() ]).then(function(t) {});
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this.data.sys;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login"
        };
    }
});