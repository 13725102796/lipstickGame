var a, t = getApp();

Page({
    data: {
        order: []
    },
    onLoad: function(o) {
        a = 1;
        var r = t.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: r.basic.fontcolor,
            backgroundColor: r.basic.color
        }), wx.setNavigationBarTitle({
            title: r.basic.title
        });
    },
    onShow: function() {
        this.order();
    },
    order: function() {
        var o = this, r = this.data.order;
        t.util.request({
            url: "entry/wxapp/Order",
            method: "POST",
            data: {
                uid: t.globalData.user_id,
                page: a
            },
            success: function(t) {
                var e = t.data.data;
                if (e.length > 0) {
                    for (var i in e) r.push(e[i]);
                    a++;
                }
                console.log(r), o.setData({
                    order: r
                });
            }
        });
    },
    copy: function(a) {
        var t = a.currentTarget.dataset.copy;
        wx.setClipboardData({
            data: t,
            success: function(a) {
                wx.showToast({
                    title: "复制成功"
                });
            }
        });
    },
    onReachBottom: function() {
        this.order();
    },
    onShareAppMessage: function() {
        var a = t.globalData.sys, o = t.globalData.user_id;
        return {
            title: a.forward.title,
            imageUrl: a.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + o
        };
    }
});