var t, a = getApp(), i = 1;

Page({
    data: {
        orderstatus: [ "一级", "二级", "三级" ],
        selindex: 0,
        Teamlist: []
    },
    onLoad: function(t) {
        var o = a.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: o.basic.fontcolor,
            backgroundColor: o.basic.color
        }), i = 1, wx.setNavigationBarTitle({
            title: o.fenxiao.ctitle[0]
        }), this.setData({
            windowWidth: a.globalData.screenWidth
        });
    },
    click: function(a) {
        var o = a.currentTarget.dataset.index;
        i = 1, t = 0 == o ? "" : 3 == o ? 3 : parseInt(o) - 1, this.setData({
            selindex: o,
            Teamlist: []
        }), Promise.all([ this.CommissionList(), this.CommissionCount() ]).then(function(t) {});
    },
    onReady: function() {},
    onShow: function() {
        var t = a.globalData.sys.fenxiao.level;
        this.setData({
            level: t
        }), this.CommissionCount(), this.CommissionList(), 1 == a.globalData.sys.basic.seal ? wx.onUserCaptureScreen(function(t) {
            wx.setStorageSync("screen", !0), wx.navigateBack({
                delta: 2
            });
        }) : wx.setStorageSync("screen", !1);
    },
    CommissionCount: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/CommissionCount",
            method: "POST",
            data: {
                uid: a.globalData.user_id
            },
            success: function(a) {
                t.setData({
                    CommissionCount: a.data.data
                });
            }
        });
    },
    CommissionList: function() {
        var t = this.data.Teamlist, o = this, s = parseInt(o.data.selindex) + 1;
        a.util.request({
            url: "entry/wxapp/CommissionList",
            method: "POST",
            data: {
                uid: a.globalData.user_id,
                level: s,
                page: i
            },
            success: function(a) {
                var s = a.data.data;
                if (s.length > 0) {
                    for (var e in s) t.push(s[e]);
                    i++;
                }
                o.setData({
                    Teamlist: t
                });
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.CommissionList();
    },
    onShareAppMessage: function() {
        var t = a.globalData.sys, i = a.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + i
        };
    }
});