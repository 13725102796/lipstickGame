var t, e = getApp();

Page({
    data: {
        shadow: !0,
        getmoney: !0,
        change: !0
    },
    onLoad: function(t) {
        var a = e.globalData.screenHeight, o = e.globalData.screenWidth, s = e.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: s.basic.fontcolor,
            backgroundColor: s.basic.color
        }), wx.setNavigationBarTitle({
            title: s.basic.title
        });
        var n = wx.getStorageSync("user");
        this.setData({
            user: n,
            sys: s,
            screenWidth: o,
            Lwidth: o / 4,
            screenHeight: a
        });
    },
    onShow: function() {
        Promise.all([ this.sys(), this.Mymoney(), this.Myrouge(), this.Checkmoneycode(), this.Canmoney() ]).then(function(t) {});
    },
    Checkmoneycode: function() {
        e.util.request({
            url: "entry/wxapp/Checkmoneycode",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(e) {
                console.log("res", e), t = e.data.data;
            }
        });
    },
    getaddress: function() {
        var t = this;
        wx.getSetting({
            success: function(e) {
                void 0 == e.authSetting["scope.address"] ? t.getAddress() : e.authSetting["scope.address"] ? t.getAddress() : t.setData({
                    shadow: !1
                });
            }
        });
    },
    sys: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/sys",
            method: "POST",
            success: function(a) {
                e.globalData.sys = a.data.data;
                var o = a.data.data;
                t.setData({
                    sys: o
                });
            }
        });
    },
    getmoney: function() {
        this.setData({
            getmoney: !1
        });
        var t = this;
        e.util.request({
            url: "entry/wxapp/Cash",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(e) {
                wx.showModal({
                    title: "温馨提示",
                    content: e.data.message,
                    showCancel: !1
                }), t.Canmoney();
            }
        }), setTimeout(function() {
            t.setData({
                getmoney: !0
            });
        }, 3e3);
    },
    changecash: function() {
        var t = this;
        if (0 == parseFloat(this.data.fenxiaomoney)) return wx.showToast({
            title: "余额不足"
        }), !1;
        wx.showModal({
            title: "温馨提示",
            content: "推广收益转进余额可以继续游戏，但不能直接提现。",
            success: function(a) {
                a.confirm && e.util.request({
                    url: "entry/wxapp/Yuetomoney",
                    method: "POST",
                    data: {
                        uid: e.globalData.user_id
                    },
                    success: function(e) {
                        console.log("转余额success", e.data.message), wx.showToast({
                            title: e.data.message,
                            icon: "none"
                        }), setTimeout(function() {
                            Promise.all([ t.Mymoney(), t.Canmoney() ]).then(function(t) {});
                        }, 1e3);
                    },
                    fail: function(t) {
                        console.log("转余额fail", t);
                    }
                });
            }
        });
    },
    getAddress: function() {
        var t = this;
        wx.chooseAddress({
            success: function(e) {
                var a = e.provinceName + "," + e.cityName + "," + e.countyName + e.detailInfo, o = e.telNumber, s = e.userName;
                t.setData({
                    address: a,
                    telphone: o,
                    userName: s
                }), t.submitaddress(a, o, s);
            }
        });
    },
    order: function() {
        wx.navigateTo({
            url: "order/order"
        });
    },
    detail: function() {
        wx.navigateTo({
            url: "distribution/distribution"
        });
    },
    vip: function(t) {
        var e = t.currentTarget.dataset.level;
        wx.navigateTo({
            url: "distribution/detail?vip=" + e
        });
    },
    cash: function() {
        wx.navigateTo({
            url: "cash/cash"
        });
    },
    Qrcode: function() {
        wx.navigateTo({
            url: "share"
        });
    },
    qrcode: function() {
        wx.navigateTo({
            url: "qrcode/qrcode?code=" + t
        });
    },
    group: function() {
        wx.navigateTo({
            url: "group/group"
        });
    },
    index: function() {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    Myrouge: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/Myrouge",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(e) {
                t.setData({
                    Myrouge: e.data.data
                });
            }
        });
    },
    Canmoney: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/Canmoney",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(e) {
                t.setData({
                    fenxiaomoney: e.data.data.money,
                    level: e.data.data.level,
                    levelno: e.data.data.levelno
                });
            }
        });
    },
    Mymoney: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/Mymoney",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(e) {
                t.setData({
                    Allmoney: e.data.data
                });
            }
        });
    },
    close: function() {
        this.setData({
            shadow: !0
        });
    },
    submitaddress: function(t, a, o) {
        var s = this;
        e.util.request({
            url: "entry/wxapp/Address",
            method: "POST",
            data: {
                uid: e.globalData.user_id,
                username: o,
                mobile: a,
                address: t
            },
            success: function(t) {
                wx.showToast({
                    title: "地址获取成功"
                }), s.setData({
                    Allmoney: t.data.data
                });
            }
        });
    },
    share: function() {
        wx.navigateTo({
            url: "share/share"
        });
    },
    onShareAppMessage: function() {
        var t = e.globalData.sys, a = e.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + a
        };
    }
});