var o = require("../../../siteinfo.js"), a = getApp();

Page({
    data: {},
    onShow: function() {
        var a = new Date().valueOf();
        console.log(a);
        var t = o.siteroot + "?i=" + o.acid + "&c=entry&m=hc_doudou&do=games&game=1?version=" + a;
        this.setData({
            url: t
        });
    },
    onLoad: function(o) {
        var t = a.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: t.basic.fontcolor,
            backgroundColor: t.basic.color
        }), wx.setNavigationBarTitle({
            title: t.basic.title
        });
    },
    Test: function(o) {
        o.detail.data;
        console.log(o);
    },
    onShareAppMessage: function() {
        var o = a.globalData.sys;
        return {
            title: o.forward.title,
            imageUrl: o.forward.img,
            path: "hc_doudou/pages/login/login"
        };
    }
});