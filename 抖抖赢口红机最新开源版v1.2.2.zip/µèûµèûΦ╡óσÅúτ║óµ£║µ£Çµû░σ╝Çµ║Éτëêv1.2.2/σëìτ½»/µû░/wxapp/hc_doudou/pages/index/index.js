var t, a = require("../../../wxParse/wxParse.js"), e = getApp();

Page({
    data: {
        login: !1,
        shadow: !0,
        pay: !0,
        notice: !0,
        nomoney: !0,
        balance: !0,
        level: !0,
        videoPlay: !0,
        videoPause: !0
    },
    onLoad: function(t) {
        var a = e.globalData.screenHeight, s = e.globalData.screenWidth;
        this.setData({
            system: e.globalData.system,
            screenWidth: s,
            screenHeight: a
        });
    },
    Jine: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/Jine",
            method: "POST",
            success: function(a) {
                t.setData({
                    sysmoney: a.data.data
                });
            }
        });
    },
    goods: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/goods",
            method: "POST",
            success: function(a) {
                t.setData({
                    goods: a.data.data
                });
            }
        });
    },
    onShow: function() {
        Promise.all([ this.check(), this.Jine(), this.goods() ]).then(function(t) {});
        var s = e.globalData.sys, o = s.basic.explain;
        a.wxParse("article", "html", o, this, 5), wx.setNavigationBarColor({
            frontColor: s.basic.fontcolor,
            backgroundColor: s.basic.color
        }), wx.setNavigationBarTitle({
            title: s.basic.title
        }), (t = wx.getStorageSync("closevoice")) && (this.back = wx.getBackgroundAudioManager(), 
        this.back.src = s.basic.bgm, this.back.title = s.basic.title, this.back.play()), 
        this.setData({
            sys: s,
            closeV: t
        });
    },
    closevoice: function(a) {
        var s = e.globalData.sys;
        a.currentTarget.dataset.voice;
        t ? (t = !1, this.back.stop(), wx.setStorageSync("closevoice", !1)) : (this.back = wx.getBackgroundAudioManager(), 
        this.back.src = s.basic.bgm, this.back.title = s.basic.title, this.back.play(), 
        t = !0, wx.setStorageSync("closevoice", !0)), this.setData({
            closeV: t
        });
    },
    goplay: function(t) {
        e.util.request({
            url: "entry/wxapp/Play",
            method: "POST",
            data: {
                uid: e.globalData.user_id,
                gid: t
            },
            success: function(t) {
                console.log("asdas", t), wx.navigateTo({
                    url: "../play/play?orderId=" + t.data.data.trade_no
                });
            }
        });
    },
    detail: function(t) {
        var a = this.data.system;
        if (1 == e.globalData.sys.pay.ios && "And" != a) return wx.showToast({
            title: "IOS暂不能体验，请耐心等待",
            icon: "none"
        }), !1;
        var s, o, n = t.currentTarget.dataset.need, i = t.currentTarget.dataset.id;
        parseInt(this.data.Allmoney) >= n ? (this.goplay(i), s = !0, o = !0) : (s = !1, 
        o = !1), this.setData({
            shadow: o,
            balance: s
        });
    },
    goMoney: function() {
        this.setData({
            balance: !0,
            pay: !1
        });
    },
    level: function() {
        this.setData({
            shadow: !1,
            level: !1,
            balance: !0
        });
    },
    closeLevel: function() {
        this.setData({
            shadow: !0,
            level: !0
        });
    },
    notice: function() {
        this.setData({
            shadow: !1,
            notice: !1
        });
    },
    closePay: function() {
        this.setData({
            shadow: !0,
            pay: !0,
            notice: !0
        });
    },
    onUnload: function() {
        console.log("暂停"), this.back.stop();
    },
    check: function() {
        var t = this;
        wx.checkSession({
            success: function(a) {
                if (!wx.getStorageSync("user")) return console.log("go"), !1;
                console.log("未过期"), t.register();
            },
            fail: function(a) {
                console.log("已过期"), t.setData({
                    login: !1
                });
            }
        });
    },
    buy: function(t) {
        var a = this, s = t.currentTarget.dataset.money;
        e.util.request({
            url: "entry/wxapp/Recharge",
            method: "POST",
            data: {
                money: s,
                uid: e.globalData.user_id
            },
            success: function(t) {
                a.pay(t.data.data);
            }
        });
    },
    pay: function(t) {
        var a = this;
        wx.requestPayment({
            timeStamp: "" + t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.sign,
            success: function(t) {
                console.log("支付成功", t), a.setData({
                    shadow: !0,
                    pay: !0
                });
            },
            fail: function(t) {}
        });
    },
    getUserInfo: function(t) {
        a = this;
        this.setData({
            disabled: !0
        });
        var a = this;
        wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] && a.login(t);
            }
        }), setTimeout(function() {
            a.setData({
                disabled: !1
            });
        }, 2e3);
    },
    play: function() {
        wx.navigateTo({
            url: "../try/try"
        });
    },
    my: function() {
        wx.reLaunch({
            url: "../my/my"
        });
    },
    login: function(t) {
        var a = this;
        wx.login({
            success: function(s) {
                var o = t.detail;
                e.globalData.userInfo = o, e.util.request({
                    url: "entry/wxapp/Getopenid",
                    method: "post",
                    dataType: "json",
                    data: {
                        code: s.code
                    },
                    success: function(s) {
                        0 == s.data.errno && (o.session_key = s.data.data.session_key, o.openid = s.data.data.openid, 
                        e.globalData.userInfo = o, wx.setStorageSync("user", t), "function" == typeof cb && cb(e.globalData.userInfo), 
                        a.register());
                    }
                });
            },
            fail: function(t) {}
        });
    },
    register: function(t) {
        var a = this, s = (a.data.selfuid, a.data.selflevel, a.data.wechat, a.data.getreward, 
        wx.getStorageSync("user").detail), o = s.session_key, n = s.openid, i = s.iv, c = s.encryptedData;
        e.util.request({
            url: "entry/wxapp/Getuserinfo",
            method: "post",
            dataType: "json",
            data: {
                session_key: o,
                encryptedData: c,
                iv: i,
                openid: n
            },
            success: function(t) {
                e.globalData.user_id = t.data.data, Promise.all([ a.Mymoney(t.data.data), a.Bindnexus(t.data.data) ]).then(function(t) {}), 
                a.setData({
                    login: !0
                });
            }
        });
    },
    Bindnexus: function(t) {
        var a = wx.getStorageSync("pid");
        console.log("hahapid", a);
        a && e.util.request({
            url: "entry/wxapp/Bindnexus",
            method: "POST",
            data: {
                uid: t,
                pid: a
            },
            success: function(t) {}
        });
    },
    Mymoney: function(t) {
        var a = this;
        e.util.request({
            url: "entry/wxapp/Mymoney",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(t) {
                a.setData({
                    Allmoney: t.data.data
                });
            }
        });
    },
    onShareAppMessage: function() {
        var t = e.globalData.sys, a = e.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + a
        };
    }
});