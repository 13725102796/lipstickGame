var o, a, t, e = getApp();

Page({
    data: {},
    onLoad: function() {
        var t = this;
        wx.authorize({
            scope: "scope.writePhotosAlbum"
        });
        var s = e.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: s.basic.fontcolor,
            backgroundColor: s.basic.color
        }), wx.setNavigationBarTitle({
            title: "生成海报"
        }), wx.showToast({
            title: "加载图片..."
        }), console.log("bgimg", s.fenxiao.bgimg), wx.getImageInfo({
            src: s.fenxiao.bgimg,
            success: function(o) {
                wx.hideToast(), console.log("download", o.path), wx.setStorageSync("logoBg", o.path), 
                t.drawImg();
            },
            fail: function(o) {
                console.log(o), wx.showToast({
                    title: "加载失败"
                });
            }
        }), wx.getSystemInfo({
            success: function(e) {
                o = e.windowWidth, a = e.windowHeight, t.setData({
                    width: e.windowWidth,
                    height: e.windowHeight
                });
            }
        });
    },
    drawImg: function() {
        var e = wx.createCanvasContext("firstCanvas");
        t = wx.getStorageSync("logoBg"), e.save(), e.drawImage(t, 0, 0, o, a), e.restore(), 
        e.save(), e.translate(-100, -100), e.drawImage("../../resource/images/scan.jpg", o / 2, a / 2, 200, 200), 
        e.restore(), e.draw();
    },
    down: function() {
        console.log("保存图片"), wx.canvasToTempFilePath({
            canvasId: "firstCanvas",
            success: function(o) {
                console.log("保存生成的二维码", o);
                var a = o.tempFilePath;
                wx.saveImageToPhotosAlbum({
                    filePath: a,
                    success: function(o) {
                        console.log("保存成功"), wx.showToast({
                            icon: "success",
                            title: "保存成功"
                        });
                    },
                    fail: function(o) {
                        console.log("保存失败", o);
                    }
                });
            },
            fail: function(o) {
                console.log(o);
            }
        });
    },
    onShareAppMessage: function() {}
});