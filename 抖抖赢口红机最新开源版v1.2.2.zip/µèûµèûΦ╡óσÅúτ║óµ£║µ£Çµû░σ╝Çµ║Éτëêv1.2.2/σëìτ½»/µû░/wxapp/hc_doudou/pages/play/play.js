var o = require("../../../siteinfo.js"), e = getApp();

Page({
    data: {},
    onLoad: function(r) {
        var a = e.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: a.basic.fontcolor,
            backgroundColor: a.basic.color
        }), wx.setNavigationBarTitle({
            title: a.basic.title
        });
        var t = o.siteroot + "?i=" + o.acid + "&c=entry&m=hc_doudou&do=games&game=2&orderId=" + r.orderId + "&userId=" + e.globalData.user_id;
        this.setData({
            url: t
        });
    },
    Test: function(o) {
        var e = JSON.parse(o.detail.data);
        this.order(e);
    },
    order: function(o) {
        console.log("orderdata", o), e.util.request({
            url: "entry/wxapp/Result",
            method: "POST",
            data: {
                uid: o.openid,
                orderid: o.orderId,
                result: o.results,
                level: o.level
            },
            success: function(o) {
                console.log("order", o);
            },
            fail: function(o) {
                console.log("fail", o);
            }
        });
    },
    onShareAppMessage: function() {
        var o = e.globalData.sys;
        return {
            title: o.forward.title,
            imageUrl: o.forward.img,
            path: "hc_doudou/pages/login/login"
        };
    }
});