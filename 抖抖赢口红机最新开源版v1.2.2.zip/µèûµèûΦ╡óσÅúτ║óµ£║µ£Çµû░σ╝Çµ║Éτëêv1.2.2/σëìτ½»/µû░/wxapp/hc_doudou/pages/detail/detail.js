var t = getApp();

Page({
    data: {},
    onLoad: function(a) {
        var e = t.globalData.screenHeight, i = t.globalData.screenWidth, o = t.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: o.basic.fontcolor,
            backgroundColor: o.basic.color
        }), wx.setNavigationBarTitle({
            title: o.basic.title
        }), this.setData({
            screenHeight: e,
            screenWidth: i
        }), this.detail(a.id);
    },
    detail: function(a) {
        var e = this;
        t.util.request({
            url: "entry/wxapp/Checkgoods_detail",
            method: "POST",
            data: {
                gid: a
            },
            success: function(t) {
                e.setData({
                    detail: t.data.data
                });
            }
        });
    }
});