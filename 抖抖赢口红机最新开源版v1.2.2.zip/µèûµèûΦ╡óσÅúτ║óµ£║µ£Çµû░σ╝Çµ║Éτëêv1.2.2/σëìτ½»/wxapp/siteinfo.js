var i = {
    uniacid: "96",
    acid: "96",
    multiid: "0",
    version: "1.0.5",
    siteroot: "https://bbs.heirui.cn/app/index.php",
    design_method: "3"
};

module.exports = i;