var t, e, a, o = getApp();

Page({
    data: {
        videoPlay: !0,
        examine: !0,
        noexamine: !0
    },
    pass: function() {
        this.setData({
            videoPlay: !0
        }), wx.reLaunch({
            url: "../index/index"
        });
    },
    end: function() {
        this.setData({
            videoPlay: !0
        }), wx.reLaunch({
            url: "../index/index"
        });
    },
    onLoad: function(t) {
        console.log("options", t), t.pid && wx.setStorageSync("pid", t.pid), t.scene && wx.setStorageSync("pid", t.scene);
        var e = o.globalData.screenHeight, a = o.globalData.screenWidth;
        this.setData({
            screenWidth: a,
            screenHeight: e
        });
    },
    sys: function() {
        var n = this, i = this;
        o.util.request({
            url: "entry/wxapp/sys",
            method: "POST",
            success: function(s) {
                var r = s.data.data;
                wx.setNavigationBarColor({
                    frontColor: r.basic.fontcolor,
                    backgroundColor: r.basic.color
                }), wx.setNavigationBarTitle({
                    title: r.basic.title
                }), o.globalData.sys = r, 0 == r.stake ? (e = !1, a = !0) : (e = !0, a = !1), 0 == r.basic.video_status ? (n.videoContext = wx.createVideoContext("myVideo"), 
                n.videoContext.play(), t = !1) : wx.reLaunch({
                    url: "../index/index"
                }), i.setData({
                    sys: r,
                    examine: e,
                    noexamine: a,
                    videoPlay: t
                });
            }
        });
    },
    Checkgoods: function() {
        var t = this;
        o.util.request({
            url: "entry/wxapp/Checkgoods",
            method: "POST",
            success: function(e) {
                t.setData({
                    goodss: e.data.data
                });
            }
        });
    },
    details: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../detail/detail?id=" + e
        });
    },
    onShow: function() {
        Promise.all([ this.sys(), this.Checkgoods() ]).then(function(t) {});
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this.data.sys;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login"
        };
    }
});