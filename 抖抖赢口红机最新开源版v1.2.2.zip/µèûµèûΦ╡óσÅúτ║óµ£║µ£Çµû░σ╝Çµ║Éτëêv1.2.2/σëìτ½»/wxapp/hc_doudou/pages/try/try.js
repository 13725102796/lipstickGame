var a = require("../../../siteinfo.js"), o = getApp();

Page({
    data: {},
    onLoad: function(t) {
        var i = a.siteroot + "?i=" + a.acid + "&c=entry&m=hc_doudou&do=games&game=1";
        this.setData({
            url: i
        });
        var e = o.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: e.basic.fontcolor,
            backgroundColor: e.basic.color
        }), wx.setNavigationBarTitle({
            title: e.basic.title
        });
    },
    Test: function(a) {
        a.detail.data;
        console.log(a);
    },
    onShareAppMessage: function() {
        var a = o.globalData.sys;
        return {
            title: a.forward.title,
            imageUrl: a.forward.img,
            path: "hc_doudou/pages/login/login"
        };
    }
});