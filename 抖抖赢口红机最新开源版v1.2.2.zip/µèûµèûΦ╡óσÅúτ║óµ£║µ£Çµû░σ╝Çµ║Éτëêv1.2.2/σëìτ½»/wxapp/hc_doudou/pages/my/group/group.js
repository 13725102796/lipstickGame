var a, t = getApp(), e = 1;

Page({
    data: {
        orderstatus: [ "一级", "二级", "三级" ],
        selindex: 0,
        Teamlist: []
    },
    onLoad: function(a) {
        var s = t.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: s.basic.fontcolor,
            backgroundColor: s.basic.color
        }), e = 1, wx.setNavigationBarTitle({
            title: "我的团队"
        }), this.setData({
            windowWidth: t.globalData.screenWidth
        });
    },
    click: function(t) {
        var s = t.currentTarget.dataset.index;
        e = 1, a = 0 == s ? "" : 3 == s ? 3 : parseInt(s) - 1, this.setData({
            selindex: s,
            Teamlist: []
        }), this.Teamlist(), this.Teamcount();
    },
    onShow: function() {
        var a = t.globalData.sys.fenxiao.level;
        this.setData({
            level: a
        }), this.Teamlist(), this.Teamcount(), 1 == t.globalData.sys.basic.seal ? wx.onUserCaptureScreen(function(a) {
            wx.setStorageSync("screen", !0), wx.navigateBack({
                delta: 2
            });
        }) : wx.setStorageSync("screen", !1);
    },
    Teamcount: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/Teamcount",
            method: "POST",
            data: {
                uid: t.globalData.user_id
            },
            success: function(t) {
                console.log(t.data.data.level1), a.setData({
                    Teamcount: t.data.data
                });
            }
        });
    },
    Teamlist: function() {
        var a = this.data.Teamlist, s = this, o = parseInt(s.data.selindex) + 1;
        t.util.request({
            url: "entry/wxapp/Teamlist",
            method: "POST",
            data: {
                uid: t.globalData.user_id,
                level: o,
                page: e
            },
            success: function(t) {
                var o = t.data.data;
                if (o.length > 0) {
                    for (var i in o) a.push(o[i]);
                    e++;
                }
                s.setData({
                    Teamlist: a
                });
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.Teamlist();
    },
    onShareAppMessage: function() {
        var a = t.globalData.sys, e = t.globalData.user_id;
        return {
            title: a.forward.title,
            imageUrl: a.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + e
        };
    }
});