var a = getApp(), t = 1;

Page({
    data: {
        cashlist: []
    },
    onLoad: function(o) {
        var s = a.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: s.basic.fontcolor,
            backgroundColor: s.basic.color
        }), t = 1, wx.setNavigationBarTitle({
            title: "提现记录"
        });
    },
    onReady: function() {},
    onShow: function() {
        this.cash(), 1 == a.globalData.sys.basic.seal ? wx.onUserCaptureScreen(function(a) {
            console.log("res", a), wx.setStorageSync("screen", !0), wx.navigateBack({
                delta: 2
            });
        }) : wx.setStorageSync("screen", !1);
    },
    cash: function() {
        var o = this, s = o.data.cashlist;
        a.util.request({
            url: "entry/wxapp/CashList",
            method: "POST",
            data: {
                page: t,
                uid: a.globalData.user_id
            },
            success: function(a) {
                console.log("cash", a);
                var n = a.data.data;
                if (n.length > 0) {
                    t++;
                    for (var e in n) s.push(n[e]);
                }
                o.setData({
                    cashlists: s
                });
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.cash();
    },
    onShareAppMessage: function() {
        var t = a.globalData.sys, o = a.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + o
        };
    }
});