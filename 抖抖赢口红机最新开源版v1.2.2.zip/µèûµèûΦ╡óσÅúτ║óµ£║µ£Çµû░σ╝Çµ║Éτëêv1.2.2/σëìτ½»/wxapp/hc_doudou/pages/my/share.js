var o = getApp();

Page({
    data: {},
    onLoad: function(a) {
        var t = o.globalData.user_id, n = o.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: n.basic.fontcolor,
            backgroundColor: n.basic.color
        }), wx.setNavigationBarTitle({
            title: "生成海报"
        });
        var r = this;
        o.util.request({
            url: "entry/wxapp/Qrcode",
            method: "post",
            dataType: "json",
            data: {
                uid: t
            },
            success: function(o) {
                wx.showToast({
                    title: "点击预览，长按保存到手机",
                    icon: "none"
                }), r.setData({
                    src: o.data.data
                });
            }
        });
    },
    download: function(o) {
        var a = o.currentTarget.dataset.src, t = [];
        t.push(a), wx.previewImage({
            urls: t,
            current: t[0]
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var a = o.globalData.sys, t = o.globalData.user_id;
        return {
            title: a.forward.title,
            imageUrl: a.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + t
        };
    }
});