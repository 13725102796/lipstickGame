var t, a = getApp(), s = 1;

Page({
    data: {
        orderstatus: [ "一级", "二级", "三级" ],
        selindex: 0,
        Teamlist: []
    },
    onLoad: function(t) {
        var i = a.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: i.basic.fontcolor,
            backgroundColor: i.basic.color
        }), s = 1, wx.setNavigationBarTitle({
            title: "分销明细"
        }), this.setData({
            windowWidth: a.globalData.screenWidth
        });
    },
    click: function(a) {
        var i = a.currentTarget.dataset.index;
        s = 1, t = 0 == i ? "" : 3 == i ? 3 : parseInt(i) - 1, this.setData({
            selindex: i,
            Teamlist: []
        }), this.CommissionList(), this.CommissionCount();
    },
    onReady: function() {},
    onShow: function() {
        var t = a.globalData.sys.fenxiao.level;
        this.setData({
            level: t
        }), this.CommissionCount(), this.CommissionList(), 1 == a.globalData.sys.basic.seal ? wx.onUserCaptureScreen(function(t) {
            wx.setStorageSync("screen", !0), wx.navigateBack({
                delta: 2
            });
        }) : wx.setStorageSync("screen", !1);
    },
    CommissionCount: function() {
        var t = this;
        a.util.request({
            url: "entry/wxapp/CommissionCount",
            method: "POST",
            data: {
                uid: a.globalData.user_id
            },
            success: function(a) {
                t.setData({
                    CommissionCount: a.data.data
                });
            }
        });
    },
    CommissionList: function() {
        var t = this.data.Teamlist, i = this, o = parseInt(i.data.selindex) + 1;
        a.util.request({
            url: "entry/wxapp/CommissionList",
            method: "POST",
            data: {
                uid: a.globalData.user_id,
                level: o,
                page: s
            },
            success: function(a) {
                var o = a.data.data;
                if (o.length > 0) {
                    for (var e in o) t.push(o[e]);
                    s++;
                }
                i.setData({
                    Teamlist: t
                });
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.CommissionList();
    },
    onShareAppMessage: function() {
        var t = a.globalData.sys, s = a.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + s
        };
    }
});