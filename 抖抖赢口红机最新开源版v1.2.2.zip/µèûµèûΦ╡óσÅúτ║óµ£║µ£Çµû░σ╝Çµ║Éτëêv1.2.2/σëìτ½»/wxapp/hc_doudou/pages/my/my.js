var t = getApp();

Page({
    data: {
        shadow: !0,
        getmoney: !0
    },
    onLoad: function(a) {
        var e = t.globalData.screenHeight, s = t.globalData.screenWidth, o = t.globalData.sys;
        wx.setNavigationBarColor({
            frontColor: o.basic.fontcolor,
            backgroundColor: o.basic.color
        }), wx.setNavigationBarTitle({
            title: o.basic.title
        });
        var n = wx.getStorageSync("user");
        this.setData({
            user: n,
            sys: o,
            screenWidth: s,
            Lwidth: s / 4,
            screenHeight: e
        });
    },
    onShow: function() {
        Promise.all([ this.sys(), this.Mymoney(), this.Myrouge(), this.Canmoney() ]).then(function(t) {});
    },
    getaddress: function() {
        var t = this;
        wx.getSetting({
            success: function(a) {
                void 0 == a.authSetting["scope.address"] ? t.getAddress() : a.authSetting["scope.address"] ? t.getAddress() : t.setData({
                    shadow: !1
                });
            }
        });
    },
    sys: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/sys",
            method: "POST",
            success: function(t) {
                console.log(t.data.data);
                var e = t.data.data;
                a.setData({
                    sys: e
                });
            }
        });
    },
    getmoney: function() {
        this.setData({
            getmoney: !1
        });
        var a = this;
        t.util.request({
            url: "entry/wxapp/Cash",
            method: "POST",
            data: {
                uid: t.globalData.user_id
            },
            success: function(t) {
                wx.showModal({
                    title: "温馨提示",
                    content: t.data.message,
                    showCancel: !1
                }), a.Canmoney();
            }
        }), setTimeout(function() {
            a.setData({
                getmoney: !0
            });
        }, 3e3);
    },
    getAddress: function() {
        var t = this;
        wx.chooseAddress({
            success: function(a) {
                var e = a.provinceName + "," + a.cityName + "," + a.countyName + a.detailInfo, s = a.telNumber, o = a.userName;
                t.setData({
                    address: e,
                    telphone: s,
                    userName: o
                }), t.submitaddress(e, s, o);
            }
        });
    },
    order: function() {
        wx.navigateTo({
            url: "order/order"
        });
    },
    detail: function() {
        wx.navigateTo({
            url: "distribution/distribution"
        });
    },
    vip: function(t) {
        var a = t.currentTarget.dataset.level;
        wx.navigateTo({
            url: "distribution/detail?vip=" + a
        });
    },
    cash: function() {
        wx.navigateTo({
            url: "cash/cash"
        });
    },
    Qrcode: function() {
        wx.navigateTo({
            url: "share"
        });
    },
    group: function() {
        wx.navigateTo({
            url: "group/group"
        });
    },
    index: function() {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    Myrouge: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/Myrouge",
            method: "POST",
            data: {
                uid: t.globalData.user_id
            },
            success: function(t) {
                a.setData({
                    Myrouge: t.data.data
                });
            }
        });
    },
    Canmoney: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/Canmoney",
            method: "POST",
            data: {
                uid: t.globalData.user_id
            },
            success: function(t) {
                a.setData({
                    fenxiaomoney: t.data.data.money,
                    level: t.data.data.level,
                    levelno: t.data.data.levelno
                });
            }
        });
    },
    Mymoney: function() {
        var a = this;
        t.util.request({
            url: "entry/wxapp/Mymoney",
            method: "POST",
            data: {
                uid: t.globalData.user_id
            },
            success: function(t) {
                a.setData({
                    Allmoney: t.data.data
                });
            }
        });
    },
    close: function() {
        this.setData({
            shadow: !0
        });
    },
    submitaddress: function(a, e, s) {
        var o = this;
        t.util.request({
            url: "entry/wxapp/Address",
            method: "POST",
            data: {
                uid: t.globalData.user_id,
                username: s,
                mobile: e,
                address: a
            },
            success: function(t) {
                wx.showToast({
                    title: "地址获取成功"
                }), o.setData({
                    Allmoney: t.data.data
                });
            }
        });
    },
    share: function() {
        wx.navigateTo({
            url: "share/share"
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var a = t.globalData.sys, e = t.globalData.user_id;
        return {
            title: a.forward.title,
            imageUrl: a.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + e
        };
    }
});