var t, a = require("../../../wxParse/wxParse.js"), e = getApp();

Page({
    data: {
        login: !1,
        shadow: !0,
        pay: !0,
        notice: !0,
        nomoney: !0,
        balance: !0,
        level: !0,
        videoPlay: !0,
        videoPause: !0
    },
    onLoad: function(t) {
        var a = e.globalData.screenHeight, o = e.globalData.screenWidth;
        this.setData({
            system: e.globalData.system,
            screenWidth: o,
            screenHeight: a
        });
    },
    Jine: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/Jine",
            method: "POST",
            success: function(a) {
                t.setData({
                    sysmoney: a.data.data
                });
            }
        });
    },
    goods: function() {
        var t = this;
        e.util.request({
            url: "entry/wxapp/goods",
            method: "POST",
            success: function(a) {
                t.setData({
                    goods: a.data.data
                });
            }
        });
    },
    onShow: function() {
        Promise.all([ this.check(), this.Jine(), this.goods() ]).then(function(t) {});
        var o = e.globalData.sys, s = o.basic.explain;
        a.wxParse("article", "html", s, this, 5), wx.setNavigationBarColor({
            frontColor: o.basic.fontcolor,
            backgroundColor: o.basic.color
        }), wx.setNavigationBarTitle({
            title: o.basic.title
        }), t = wx.getStorageSync("closevoice"), this.audioCtx = wx.createAudioContext("myAudio"), 
        t && (this.audioCtx.setSrc(o.basic.bgm), this.audioCtx.play()), this.setData({
            sys: o,
            closeV: t
        });
    },
    closevoice: function(a) {
        var e = a.currentTarget.dataset.voice;
        t ? (t = !1, this.audioCtx.setSrc(e), wx.setStorageSync("closevoice", !1), this.audioCtx.pause()) : (t = !0, 
        this.audioCtx.setSrc(e), this.audioCtx.play(), wx.setStorageSync("closevoice", !0)), 
        this.setData({
            closeV: t
        });
    },
    goplay: function(t) {
        e.util.request({
            url: "entry/wxapp/Play",
            method: "POST",
            data: {
                uid: e.globalData.user_id,
                gid: t
            },
            success: function(t) {
                console.log("asdas", t), wx.navigateTo({
                    url: "../play/play?orderId=" + t.data.data.trade_no
                });
            }
        });
    },
    detail: function(t) {
        var a = this.data.system;
        if (1 == e.globalData.sys.pay.ios && "And" != a) return wx.showToast({
            title: "IOS暂不能体验，请耐心等待",
            icon: "none"
        }), !1;
        var o, s, n = t.currentTarget.dataset.need, i = t.currentTarget.dataset.id;
        parseInt(this.data.Allmoney) >= n ? (this.goplay(i), o = !0, s = !0) : (o = !1, 
        s = !1), this.setData({
            shadow: s,
            balance: o
        });
    },
    goMoney: function() {
        this.setData({
            balance: !0,
            pay: !1
        });
    },
    level: function() {
        this.setData({
            shadow: !1,
            level: !1
        });
    },
    closeLevel: function() {
        this.setData({
            shadow: !0,
            level: !0
        });
    },
    notice: function() {
        this.setData({
            shadow: !1,
            notice: !1
        });
    },
    closePay: function() {
        this.setData({
            shadow: !0,
            pay: !0,
            notice: !0
        });
    },
    onUnload: function() {
        this.audioCtx.pause();
    },
    check: function() {
        var t = this;
        wx.checkSession({
            success: function(a) {
                if (!wx.getStorageSync("user")) return console.log("go"), !1;
                console.log("未过期"), t.register();
            },
            fail: function(a) {
                console.log("已过期"), t.setData({
                    login: !1
                });
            }
        });
    },
    buy: function(t) {
        var a = this, o = t.currentTarget.dataset.money;
        e.util.request({
            url: "entry/wxapp/Recharge",
            method: "POST",
            data: {
                money: o,
                uid: e.globalData.user_id
            },
            success: function(t) {
                a.pay(t.data.data);
            }
        });
    },
    pay: function(t) {
        wx.requestPayment({
            timeStamp: "" + t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.sign,
            success: function(t) {
                wx.redirectTo({
                    url: "../get/get"
                });
            },
            fail: function(t) {}
        });
    },
    getUserInfo: function(t) {
        a = this;
        this.setData({
            disabled: !0
        });
        var a = this;
        wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] && a.login(t);
            }
        }), setTimeout(function() {
            a.setData({
                disabled: !1
            });
        }, 2e3);
    },
    play: function() {
        wx.navigateTo({
            url: "../try/try"
        });
    },
    my: function() {
        wx.reLaunch({
            url: "../my/my"
        });
    },
    login: function(t) {
        var a = this;
        wx.login({
            success: function(o) {
                var s = t.detail;
                e.globalData.userInfo = s, e.util.request({
                    url: "entry/wxapp/Getopenid",
                    method: "post",
                    dataType: "json",
                    data: {
                        code: o.code
                    },
                    success: function(o) {
                        0 == o.data.errno && (s.session_key = o.data.data.session_key, s.openid = o.data.data.openid, 
                        e.globalData.userInfo = s, wx.setStorageSync("user", t), "function" == typeof cb && cb(e.globalData.userInfo), 
                        a.register());
                    }
                });
            },
            fail: function(t) {}
        });
    },
    register: function(t) {
        var a = this, o = (a.data.selfuid, a.data.selflevel, a.data.wechat, a.data.getreward, 
        wx.getStorageSync("user").detail), s = o.session_key, n = o.openid, i = o.iv, c = o.encryptedData;
        e.util.request({
            url: "entry/wxapp/Getuserinfo",
            method: "post",
            dataType: "json",
            data: {
                session_key: s,
                encryptedData: c,
                iv: i,
                openid: n
            },
            success: function(t) {
                e.globalData.user_id = t.data.data, Promise.all([ a.Mymoney(t.data.data), a.Bindnexus(t.data.data) ]).then(function(t) {}), 
                a.setData({
                    login: !0
                });
            }
        });
    },
    Bindnexus: function(t) {
        var a = wx.getStorageSync("pid");
        console.log("绑定分销关系", a);
        a && e.util.request({
            url: "entry/wxapp/Bindnexus",
            method: "POST",
            data: {
                uid: t,
                pid: a
            },
            success: function(t) {
                console.log("绑定分销关系");
            }
        });
    },
    Mymoney: function(t) {
        var a = this;
        e.util.request({
            url: "entry/wxapp/Mymoney",
            method: "POST",
            data: {
                uid: e.globalData.user_id
            },
            success: function(t) {
                a.setData({
                    Allmoney: t.data.data
                });
            }
        });
    },
    onShareAppMessage: function() {
        var t = e.globalData.sys, a = e.globalData.user_id;
        return {
            title: t.forward.title,
            imageUrl: t.forward.img,
            path: "hc_doudou/pages/login/login?pid=" + a
        };
    }
});