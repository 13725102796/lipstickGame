<?php
/**
 * hc_doudou模块定义
 *
 * @author 黑锐源码社区
 * @url http://bbs.heirui.cn/
 */
defined('IN_IA') or exit('Access Denied');

class Hc_doudouModule extends WeModule {



}